package view;

import java.awt.Point;

import engine.Game;
import javafx.scene.Group;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseButton;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import model.characters.Explorer;
import model.characters.Hero;
import model.characters.Zombie;
import model.collectibles.Supply;
import model.collectibles.Vaccine;
import model.world.Cell;
import model.world.CharacterCell;
import model.world.CollectibleCell;
import model.world.TrapCell;

public class Dothemap extends Main {
	
	static Rectangle[][] squares = new Rectangle[15][15];
	public static  int i;
	public  static int j;
	public static  int iz;
	public  static int jz;
	
	int c;
	int r;
	
	public Dothemap() { 
		tmp = new Group();
		mapGrid = new GridPane();
		bpane = new VBox(10);
		
		
		mapGrid.setHgap(0.2);
        mapGrid.setVgap(0.2);
        
       
        
        for ( r = 0; r <= 14; r++) {
            for ( c = 0; c <= 14; c++) {
            	Rectangle square = new Rectangle(40,40);
                square.setFill(Color.WHITE);
                square.setStroke(Color.BLACK);
                squares[r][c] = square;
                square.setOnMouseClicked(( event) -> {
                	if(event.getButton() == MouseButton.PRIMARY) {
                		
//            			txt.setText("Name: " + hero.getName() + "\n" + "Current ActionPoints: " + hero.getActionsAvailable() +"\n" + "Current Hp: " + hero.getCurrentHp()
//            			+"\n"+ "supplies: " + hero.getSupplyInventory().size() + "\n" + "Vaccines: " + hero.getVaccineInventory().size());
//            			txt.setFill(Color.WHITE);
            			
                		i=mapGrid.getRowIndex(square);//14                    
                		j=mapGrid.getColumnIndex(square);//0
                    
                	if (Game.map[Math.abs(i-14)][j] instanceof CharacterCell) {
                		if(((CharacterCell)Game.map[Math.abs(i-14)][j]).getCharacter() instanceof Hero) { 	
                            hero =(Hero) ((CharacterCell) Game.map[Math.abs(i-14)][j]).getCharacter();
                            txt.setText("Name: " + hero.getName() + "\n" + "Current ActionPoints: " + hero.getActionsAvailable() +"\n" + "Current Hp: " + hero.getCurrentHp()
                			+"\n"+ "supplies: " + hero.getSupplyInventory().size() + "\n" + "Vaccines: " + hero.getVaccineInventory().size());
                			txt.setFill(Color.WHITE);
                		}
                	}
                	}
                	
                	
                	if(event.getButton() == MouseButton.SECONDARY) {
                		i=mapGrid.getRowIndex(square);//14                    
                        j=mapGrid.getColumnIndex(square);//0
                		if (Game.map[Math.abs(i-14)][j] instanceof CharacterCell) {
							if(((CharacterCell)Game.map[Math.abs(i-14)][j]).getCharacter() instanceof Zombie) {
                                zombie = (Zombie) ((CharacterCell) Game.map[Math.abs(i-14)][j]).getCharacter();
                                hero.setTarget(zombie);
                          
							}
							else {
								tmphero = (Hero) ((CharacterCell) Game.map[Math.abs(i-14)][j]).getCharacter();
                                hero.setTarget(tmphero);
							}
                	}
                       
                }});
                mapGrid.add(square,c,r);   
                
            }
        }
       
	}
	
	public static  void fillthemap(Cell[][] map) {
		Image figh = new Image("Figh.png");
		Image zom = new Image("Zombie.png");
		Image sup = new Image("suppp.jpg");
		Image vac = new Image("vacc.jpg");
		Image trap = new Image("trap.png");
		
		for(int r=0;r<=14;r++) {
			for(int c =0; c<=14;c++) {
				if(map[r][c] instanceof CharacterCell) {
					
					if(((CharacterCell)(map[r][c])).getCharacter() instanceof Hero) {
						if(hero instanceof Explorer && hero.isSpecialAction()) {
							fillthemap2(map);
						}
						ImageView im = new ImageView(figh);
						im.setFitHeight(40);
						im.setFitWidth(40);
						squares[Math.abs(r-14)][c].setFill(new ImagePattern(figh));				
					}
					
					if(((CharacterCell)(map[r][c])).getCharacter() instanceof Zombie) {
						ImageView im = new ImageView(zom);
						im.setFitHeight(40);
						im.setFitWidth(40);
						squares[Math.abs(r-14)][c].setFill(new ImagePattern(zom));
					}
				}
				if(map[r][c] instanceof CollectibleCell) {
					
					if(((CollectibleCell) map[r][c]).getCollectible() instanceof Supply) {
						ImageView im = new ImageView(sup);
						im.setFitHeight(40);
						im.setFitWidth(40);
						squares[Math.abs(r-14)][c].setFill(new ImagePattern(sup));
					}
					if(((CollectibleCell) map[r][c]).getCollectible() instanceof Vaccine) {
 
						ImageView im = new ImageView(vac);
						im.setFitHeight(40);
						im.setFitWidth(40);
						squares[Math.abs(r-14)][c].setFill(new ImagePattern(vac));
					}
											
				}
				if(map[r][c] instanceof TrapCell) {
					//ImageView im = new ImageView(trap);
					//im.setFitHeight(40);
					//im.setFitWidth(40);
					//squares[Math.abs(r-14)][c].setFill(Color.BEIGE);

				}
				
			}
			GridVisibility(map);
		}
	}

	
	
	public static void GridVisibility(Cell[][] map) {
		
		for(int r = 0;r<=14;r++) {
			for(int c =0;c<=14;c++) {
				if(!((Cell)map[r][c]).isVisible()) {
					squares[Math.abs(r-14)][c].setFill(Color.WHITE);
				}
			}
		}
	}
	
	public static void fillthemap2(Cell[][] map) {
		Image figh = new Image("Figh.png");
		Image zom = new Image("Zombie.png");
		Image sup = new Image("suppp.jpg");
		Image vac = new Image("vacc.jpg");
		Image trap = new Image("trap.png");
		
	for(int r=0;r<=14;r++) {
		for(int c =0; c<=14;c++) {
			if(map[r][c] instanceof CharacterCell) {
				
				if(((CharacterCell)(map[r][c])).getCharacter() instanceof Hero) {
					ImageView im = new ImageView(figh);
					im.setFitHeight(40);
					im.setFitWidth(40);
					squares[Math.abs(r-14)][c].setFill(new ImagePattern(figh));				
				}
				
				if(((CharacterCell)(map[r][c])).getCharacter() instanceof Zombie) {
					ImageView im = new ImageView(zom);
					im.setFitHeight(40);
					im.setFitWidth(40);
					squares[Math.abs(r-14)][c].setFill(new ImagePattern(zom));
				}
			}
			if(map[r][c] instanceof CollectibleCell) {
				
				if(((CollectibleCell) map[r][c]).getCollectible() instanceof Supply) {
					ImageView im = new ImageView(sup);
					im.setFitHeight(40);
					im.setFitWidth(40);
					squares[Math.abs(r-14)][c].setFill(new ImagePattern(sup));
				}
				if(((CollectibleCell) map[r][c]).getCollectible() instanceof Vaccine) {

					ImageView im = new ImageView(vac);
					im.setFitHeight(40);
					im.setFitWidth(40);
					squares[Math.abs(r-14)][c].setFill(new ImagePattern(vac));
				}
										
			}
			if(map[r][c] instanceof TrapCell) {
				ImageView im = new ImageView(trap);
				im.setFitHeight(40);
				im.setFitWidth(40);
				squares[Math.abs(r-14)][c].setFill(new ImagePattern(trap));

			}
			
		}
		
	}
}
	
	
	
	
	
	public Zombie zombieTarget() {
		Zombie z = null;
		for(int i = 0;i<Game.zombies.size();i++) {
			z = Game.zombies.get(i);
			Point p1 = new Point(z.getLocation());
			if(iz == Math.abs(p1.x-14) && jz == p1.y) {
				System.out.println("nkdankd "+ z.getName());
				return z;
			}
			
		}
		return z;
	}
	
	
	
	
	public static void addstuff(Cell[][] map) {
		for(int r =0;r<=14;r++) {
			for(int c =0;c<=14;c++) {
				
				if(map[r][c] instanceof TrapCell) {
					squares[r][c].setFill(Color.RED);
				}
				
			}
		}
	}
	
	
	
	public void set(int i,int j) {
		squares[i][j].setFill(Color.BLUE);
	}

	
	
	
	
	
	
	
	

}
