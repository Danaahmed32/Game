package view;

import java.awt.Point;
import java.io.FileInputStream;
import java.io.IOException;

import engine.Game;
import exceptions.InvalidTargetException;
import exceptions.MovementException;
import exceptions.NoAvailableResourcesException;
import exceptions.NotEnoughActionsException;
import javafx.application.Application;
import javafx.application.Platform;
import javafx.event.*;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Group;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.effect.ImageInput;
import javafx.scene.image.Image;
import javafx.scene.image.ImageView;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.Background;
import javafx.scene.layout.BackgroundImage;
import javafx.scene.layout.BackgroundPosition;
import javafx.scene.layout.BackgroundRepeat;
import javafx.scene.layout.BackgroundSize;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.Pane;
import javafx.scene.layout.StackPane;
import javafx.scene.layout.VBox;
import javafx.scene.paint.Color;
import javafx.scene.paint.ImagePattern;
import javafx.scene.shape.Rectangle;
import javafx.scene.text.Font;
import javafx.scene.text.Text;
import javafx.scene.text.TextAlignment;
import javafx.stage.Popup;
import javafx.stage.Stage;
import javafx.stage.Window;
import model.characters.Direction;
import model.characters.Explorer;
import model.characters.Fighter;
import model.characters.Hero;
import model.characters.Medic;
import model.characters.Zombie;
import model.world.Cell;
import model.world.CharacterCell;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;
import javafx.util.Duration;

public class Main extends Application {
	
	static StackPane root;
	static HBox root2;
	static GridPane mapGrid;
	static VBox bpane;
	static VBox Vtext;
	static HBox HInstructions;
	static Text Inst;
	static Group tmp;
	public Stage stage;
	public Scene scene1, scene2, scene3;
	public static Hero hero;
	public static Hero tmphero;
	public static Zombie zombie;
	public static Text txt;
	
	
	
	
	
	public void start(Stage stage) throws Exception {
		
		
        root = new StackPane();
        root.setPadding(new Insets(30));
        root2 = new HBox(7);
        txt = new Text("Aoowoo");		
        Vtext = new VBox(5);
        HInstructions = new HBox();
        HInstructions.setSpacing(10);
        HInstructions.setAlignment(Pos.TOP_CENTER);;
        HInstructions.setPadding(new Insets(10));
        Inst = new Text("Game Instructions:" + 
        "\n"+"when you start the game you need to first click on the hero before Moving" +
        "\n"+"If you want to a set your target so you can attack or cure you need to first click on your hero then right click on your target" +
        "\n"+"if you want to choose another hero to play with other than your current hero you need to click on the other hero");
         
        Inst.setTextAlignment(TextAlignment.CENTER);
		Inst.setFont(Font.font(15));
		Inst.setFill(Color.WHITE);
		Inst.setStroke(Color.RED);
		Inst.setStrokeWidth(0.1);
		
        HInstructions.getChildren().add(Inst);
		root.getChildren().add(HInstructions);
        //scene 1
        Image backgroundImage = new Image("wp10887314.jpg");
        BackgroundImage background = new BackgroundImage(backgroundImage,
                BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.CENTER,
                new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, false, false, true, false));
 
        root.setBackground(new Background(background));
        root.setAlignment(Pos.BOTTOM_CENTER);
		
		Button b1 = new Button("Start Game");
		b1.setPrefSize(130, 50);
		b1.setOnAction(e -> stage.setScene(scene2));
		root.getChildren().add(b1);
		
		scene1 = new Scene(root,1100,650,Color.BLACK);		
		
		
		//Scene 2
		Image backgroundImage2 = new Image("wp10887314.jpg");
        BackgroundImage background2 = new BackgroundImage(backgroundImage2,
                BackgroundRepeat.NO_REPEAT, BackgroundRepeat.NO_REPEAT,
                BackgroundPosition.CENTER,
                new BackgroundSize(BackgroundSize.AUTO, BackgroundSize.AUTO, false, false, true, false));

        
        root2.setBackground(new Background(background2));
        root2.setAlignment(Pos.CENTER);		
       	
        
//        loadstartgame(stage);
        
        

		Button btn0,btn1,btn2,btn3,btn4,btn5,btn6,btn7;
		String type0,type1,type2,type3,type4,type5,type6,type7;
		Dothemap m = new Dothemap();
		Game.loadHeroes("Heroes.csv");
		
		Image figh = new Image("Figh.png");
		
		if(Game.availableHeroes.get(0) instanceof Medic) {
			type0 = "Medic";
		}
		if(Game.availableHeroes.get(0) instanceof Fighter) {
			type0 = "Fighter";
		}
		else
			type0 = "Explorer"; 
        
		btn0 = new Button("Name: " + Game.availableHeroes.get(0).getName() + "\n" + "Type: "+ type0  + "\n" + "HP: " + Game.availableHeroes.get(0).getMaxHp()
				+ "\n" +"Attack dmg: " + Game.availableHeroes.get(0).getAttackDmg()+ "\n" +"Actions Available: " + Game.availableHeroes.get(0).getMaxActions());
		btn0.setPrefSize(130,110);
		btn0.setWrapText(true);
		root2.getChildren().add(btn0);
		btn0.setOnAction(e ->{
			Text data = new  Text("Name: " + Game.availableHeroes.get(0).getName() + "\n" + "Type: Fighter" +"\n" + "HP: " + Game.availableHeroes.get(0).getMaxHp()
			+"\n" +"Attack dmg: " + Game.availableHeroes.get(0).getAttackDmg() + "\n" +"Actions Available: " + Game.availableHeroes.get(0).getMaxActions());
			data.setTextAlignment(TextAlignment.CENTER);
			data.setFont(Font.font(15));
			data.setFill(Color.WHITE);
			data.setStroke(Color.RED);
			data.setStrokeWidth(0.1);
			Vtext.getChildren().add(data);
			hero = Game.availableHeroes.get(0);
			Game.startGame(hero);
			
			txt.setText("Name: " + hero.getName() + "\n" + "Current ActionPoints: " + hero.getActionsAvailable() +"\n" + "Current Hp: " + hero.getCurrentHp()
			+"\n"+ "supplies: " + hero.getSupplyInventory().size() + "\n" + "Vaccines: " + hero.getVaccineInventory().size());
			txt.setFill(Color.WHITE);
			
			m.fillthemap(Game.map);
			stage.setScene(scene3);
		});
		
		if( Game.availableHeroes.get(1) instanceof Fighter) {
			type1 = "Fighter";
		}
		if(Game.availableHeroes.get(1) instanceof Explorer) {
			type1 = "Explorer";
		}
		else
			type1 = "Medic"; 
		
			btn1 = new Button("Name: " + Game.availableHeroes.get(1).getName() + "\n" + "Type: " + type1 + "\n" + "HP: " + Game.availableHeroes.get(1).getMaxHp()
					+ "\n" +"Attack dmg: " + Game.availableHeroes.get(1).getAttackDmg()+ "\n" +"Actions Available: " + Game.availableHeroes.get(1).getMaxActions());
			btn1.setPrefSize(130,110);
			btn1.setWrapText(true);
			root2.getChildren().add(btn1);
			btn1.setOnAction(e ->{
				Text data = new  Text("Name: " + Game.availableHeroes.get(1).getName() + "\n" + "Type: Medic"  + "\n" + "HP: " + Game.availableHeroes.get(1).getMaxHp() 
						+"\n" +"Attack dmg: " + Game.availableHeroes.get(1).getAttackDmg()+ "\n" +"Actions Available: " + Game.availableHeroes.get(1).getMaxActions());
				data.setTextAlignment(TextAlignment.CENTER);
				data.setFont(Font.font(15));
				data.setFill(Color.WHITE);
				data.setStroke(Color.RED);
				data.setStrokeWidth(0.1);
				Vtext.getChildren().add(data);
				hero = Game.availableHeroes.get(1);
				Game.startGame(hero);
				
				txt.setText("Name: " + hero.getName() + "\n" + "Current ActionPoints: " + hero.getActionsAvailable() +"\n" + "Current Hp: " + hero.getCurrentHp()
				+"\n"+ "supplies: " + hero.getSupplyInventory().size() + "\n" + "Vaccines: " + hero.getVaccineInventory().size());
				txt.setFill(Color.WHITE);
				
				m.fillthemap(Game.map);
				stage.setScene(scene3);
			});
			if( Game.availableHeroes.get(2) instanceof Fighter) {
				type2 = "Fighter";
			}
			if(Game.availableHeroes.get(2) instanceof Explorer) {
				type2 = "Explorer";
			}
			else
				type2 = "Medic"; 
			

			btn2 = new Button("Name: " + Game.availableHeroes.get(2).getName() + "\n" + "Type:" + type2 + "\n" + "HP: " + Game.availableHeroes.get(2).getMaxHp()
			+"\n" +"Attack dmg: " + Game.availableHeroes.get(2).getAttackDmg()+ "\n" +"Actions Available: " + Game.availableHeroes.get(2).getMaxActions());
			
			btn2.setPrefSize(130,110);
			btn2.setWrapText(true);
			root2.getChildren().add(btn2);
			btn2.setOnAction(e ->{
				Text data = new  Text("Name: " + Game.availableHeroes.get(2).getName() + "\n" + "Type: Explorer " + "\n" + "HP: " + Game.availableHeroes.get(2).getMaxHp()
				+ "\n" +"Attack dmg: " + Game.availableHeroes.get(2).getAttackDmg()+ "\n" +"Actions Available: " + Game.availableHeroes.get(2).getMaxActions());
				
				data.setTextAlignment(TextAlignment.CENTER);
				data.setFont(Font.font(15));
				data.setFill(Color.WHITE);
				data.setStroke(Color.RED);
				data.setStrokeWidth(0.1);
				Vtext.getChildren().add(data);
				hero = Game.availableHeroes.get(2);
				Game.startGame(hero);
				
				txt.setText("Name: " + hero.getName() + "\n" + "Current ActionPoints: " + hero.getActionsAvailable() +"\n" + "Current Hp: " + hero.getCurrentHp()
				+"\n"+ "supplies: " + hero.getSupplyInventory().size() + "\n" + "Vaccines: " + hero.getVaccineInventory().size());
				txt.setFill(Color.WHITE);
				
				m.fillthemap(Game.map);
				stage.setScene(scene3);
			});
			
			if( Game.availableHeroes.get(3) instanceof Fighter) {
				type3 = "Fighter";
			}
			if(Game.availableHeroes.get(3) instanceof Explorer) {
				type3 = "Explorer";
			}
			else
				type3 = "Medic"; 
			
			btn3 = new Button("Name: " + Game.availableHeroes.get(3).getName() + "\n" + "Type: "+ type3  + "\n" + "HP: " + Game.availableHeroes.get(3).getMaxHp()
			+ "\n" +"Attack dmg: " + Game.availableHeroes.get(3).getAttackDmg()+ "\n" +"Actions Available: " + Game.availableHeroes.get(3).getMaxActions());
			
			btn3.setPrefSize(130,110);
			btn3.setWrapText(true);
			root2.getChildren().add(btn3);
			btn3.setOnAction(e ->{
				Text data = new  Text("Name: " + Game.availableHeroes.get(3).getName() + "\n" + "Type: Explorer "  + "\n" + "HP: " + Game.availableHeroes.get(3).getMaxHp() + "\n" +"Attack dmg: " + Game.availableHeroes.get(3).getAttackDmg()
				+ "\n" +"Actions Available: " + Game.availableHeroes.get(3).getMaxActions());
				
				data.setTextAlignment(TextAlignment.CENTER);
				data.setFont(Font.font(15));
				data.setFill(Color.WHITE);
				data.setStroke(Color.RED);
				data.setStrokeWidth(0.1);
				Vtext.getChildren().add(data);
				hero = Game.availableHeroes.get(3);
				Game.startGame(hero);
				
				txt.setText("Name: " + hero.getName() + "\n" + "Current ActionPoints: " + hero.getActionsAvailable() +"\n" + "Current Hp: " + hero.getCurrentHp()
				+"\n"+ "supplies: " + hero.getSupplyInventory().size() + "\n" + "Vaccines: " + hero.getVaccineInventory().size());
				txt.setFill(Color.WHITE);
				
				m.fillthemap(Game.map);
				stage.setScene(scene3);
			});
			
			if( Game.availableHeroes.get(4) instanceof Fighter) {
				type4 = "Fighter";
			}
			if(Game.availableHeroes.get(4) instanceof Explorer) {
				type4 = "Explorer";
			}
			else
				type4 = "Medic"; 
			
				btn4 = new Button("Name: " + Game.availableHeroes.get(4).getName() + "\n" + "Type: "+ type4  + "\n" + "HP: " + Game.availableHeroes.get(4).getMaxHp()
				+ "\n" +"Attack dmg: " + Game.availableHeroes.get(4).getAttackDmg()+ "\n" +"Actions Available: " + Game.availableHeroes.get(4).getMaxActions());
				
				btn4.setPrefSize(130,110);
				btn4.setWrapText(true);
				root2.getChildren().add(btn4);
				btn4.setOnAction(e ->{
					Text data = new  Text("Name: " + Game.availableHeroes.get(4).getName() + "\n" + "Type: Explorer "  + "\n" + "HP: " + Game.availableHeroes.get(4).getMaxHp()
					+ "\n" +"Attack dmg: " + Game.availableHeroes.get(4).getAttackDmg()+ "\n" +"Actions Available: " + Game.availableHeroes.get(4).getMaxActions());
					
					data.setTextAlignment(TextAlignment.CENTER);
					data.setFont(Font.font(15));
					data.setFill(Color.WHITE);
					data.setStroke(Color.RED);
					data.setStrokeWidth(0.1);
					Vtext.getChildren().add(data);
					hero = Game.availableHeroes.get(4);
					Game.startGame(hero);
					
					txt.setText("Name: " + hero.getName() + "\n" + "Current ActionPoints: " + hero.getActionsAvailable() +"\n" + "Current Hp: " + hero.getCurrentHp()
					+"\n"+ "supplies: " + hero.getSupplyInventory().size() + "\n" + "Vaccines: " + hero.getVaccineInventory().size());
					txt.setFill(Color.WHITE);
					
					m.fillthemap(Game.map);
					stage.setScene(scene3);
				});

				if( Game.availableHeroes.get(5) instanceof Fighter) {
					type5 = "Fighter";
				}
				if(Game.availableHeroes.get(5) instanceof Explorer) {
					type5 = "Explorer";
				}
				else
					type5 = "Medic"; 
				
				btn5 = new Button("Name: " + Game.availableHeroes.get(5).getName() + "\n" + "Type: " + type5 + "\n" + "HP: " + Game.availableHeroes.get(5).getMaxHp() 
				+ "\n" +"Attack dmg: " + Game.availableHeroes.get(5).getAttackDmg()+ "\n" +"Actions Available: " + Game.availableHeroes.get(5).getMaxActions());
				
				btn5.setPrefSize(130,110);
				btn5.setWrapText(true);
				root2.getChildren().add(btn5);
				btn5.setOnAction(e ->{
					Text data = new  Text("Name: " + Game.availableHeroes.get(5).getName() + "\n" + "Type: Medic"  + "\n" + "HP: " + Game.availableHeroes.get(5).getMaxHp()
					+ "\n" +"Attack dmg: " + Game.availableHeroes.get(5).getAttackDmg()+ "\n" +"Actions Available: " + Game.availableHeroes.get(5).getMaxActions());
					
					data.setTextAlignment(TextAlignment.CENTER);
					data.setFont(Font.font(15));
					data.setFill(Color.WHITE);
					data.setStroke(Color.RED);
					data.setStrokeWidth(0.1);
					Vtext.getChildren().add(data);
					hero = Game.availableHeroes.get(5);
					Game.startGame(hero);
					
					txt.setText("Name: " + hero.getName() + "\n" + "Current ActionPoints: " + hero.getActionsAvailable() +"\n" + "Current Hp: " + hero.getCurrentHp()
					+"\n"+ "supplies: " + hero.getSupplyInventory().size() + "\n" + "Vaccines: " + hero.getVaccineInventory().size());
					txt.setFill(Color.WHITE);
					
					m.fillthemap(Game.map);
					stage.setScene(scene3);
				});
				
				if(Game.availableHeroes.get(0) instanceof Medic) {
					type6 = "Medic";
				}
				if(Game.availableHeroes.get(0) instanceof Fighter) {
					type6 = "Fighter";
				}
				else
					type6 = "Explorer"; 
				
				btn6 = new Button("Name: " + Game.availableHeroes.get(6).getName() + "\n" + "Type: "+ type6  + "\n" + "HP: " + Game.availableHeroes.get(6).getMaxHp() 
				+ "\n" +"Attack dmg: " + Game.availableHeroes.get(6).getAttackDmg()+ "\n" +"Actions Available: " + Game.availableHeroes.get(6).getMaxActions());
				
				btn6.setPrefSize(130,110);
				btn6.setWrapText(true);
				root2.getChildren().add(btn6);
				btn6.setOnAction(e ->{
					Text data = new  Text("Name: " + Game.availableHeroes.get(6).getName() + "\n" + "Type: Fighter"  + "\n" + "HP: " + Game.availableHeroes.get(6).getMaxHp()
					+ "\n" +"Attack dmg: " + Game.availableHeroes.get(6).getAttackDmg()+ "\n" +"Actions Available: " + Game.availableHeroes.get(6).getMaxActions());
					
					data.setTextAlignment(TextAlignment.CENTER);
					data.setFont(Font.font(15));
					data.setFill(Color.WHITE);
					data.setStroke(Color.RED);
					data.setStrokeWidth(0.1);
					Vtext.getChildren().add(data);
					hero = Game.availableHeroes.get(6);
					Game.startGame(hero);
					
					txt.setText("Name: " + hero.getName() + "\n" + "Current ActionPoints: " + hero.getActionsAvailable() +"\n" + "Current Hp: " + hero.getCurrentHp()
					+"\n"+ "supplies: " + hero.getSupplyInventory().size() + "\n" + "Vaccines: " + hero.getVaccineInventory().size());
					txt.setFill(Color.WHITE);
					
					m.fillthemap(Game.map);
					stage.setScene(scene3);
				});
				
				if( Game.availableHeroes.get(7) instanceof Fighter) {
					type7 = "Fighter";
				}
				if(Game.availableHeroes.get(7) instanceof Explorer) {
					type7 = "Explorer";
				}
				else
					type7 = "Medic"; 
				
				btn7 = new Button("Name: " + Game.availableHeroes.get(7).getName() + "\n" + "Type: "+ type7  + "\n" + "HP: " + Game.availableHeroes.get(7).getMaxHp()
				+ "\n" +"Attack dmg: " + Game.availableHeroes.get(7).getAttackDmg()+ "\n" +"Actions Available: " + Game.availableHeroes.get(7).getMaxActions());
				
				btn7.setPrefSize(130,110);
				btn7.setWrapText(true);
				root2.getChildren().add(btn7);
				btn7.setOnAction(e ->{
					Text data = new  Text("Name: " + Game.availableHeroes.get(7).getName() + "\n" + "Type: Medic"  + "\n" + "HP: " + Game.availableHeroes.get(7).getMaxHp()
					+ "\n" +"Attack dmg: " + Game.availableHeroes.get(7).getAttackDmg()+ "\n" +"Actions Available: " + Game.availableHeroes.get(7).getMaxActions());
					
					data.setTextAlignment(TextAlignment.CENTER);
					data.setFont(Font.font(15));
					data.setFill(Color.WHITE);
					data.setStroke(Color.RED);
					data.setStrokeWidth(0.1);
					Vtext.getChildren().add(data);
					hero = Game.availableHeroes.get(7);
					Game.startGame(hero);
					
					txt.setText("Name: " + hero.getName() + "\n" + "Current ActionPoints: " + hero.getActionsAvailable() +"\n" + "Current Hp: " + hero.getCurrentHp()
					+"\n"+ "supplies: " + hero.getSupplyInventory().size() + "\n" + "Vaccines: " + hero.getVaccineInventory().size());
					txt.setFill(Color.WHITE);
					
					m.fillthemap(Game.map);
					stage.setScene(scene3);
				});
	
        
        
		
		Button Atk = new Button("Attack");
		Atk.setPrefSize(120, 30);
		Atk.setOnMouseClicked(e ->{
			
			
			try {
				
				hero.attack();
				
				txt.setText("Name: " + hero.getName() + "\n" + "Current ActionPoints: " + hero.getActionsAvailable() +"\n" + "Current Hp: " + hero.getCurrentHp()
				+"\n"+ "supplies: " + hero.getSupplyInventory().size() + "\n" + "Vaccines: " + hero.getVaccineInventory().size());
				txt.setFill(Color.WHITE);
				
				m.fillthemap(Game.map);
				
				Point p2 = new Point(hero.getTarget().getLocation());
				int k = Math.abs(p2.x-14);
				int o = p2.y;
				
				if(hero.getTarget().getCurrentHp() <= 0) {
					m.squares[k][o].setFill(Color.WHITE);
				}
				
				if(Game.checkGameOver()) {
					Gameovermsg();
				}
				
				if(Game.checkWin()) {
					Winmsg();
				}
				
				
					
			} catch (NotEnoughActionsException e1) {
				Stage tmpstage = new Stage();
				tmpstage.setTitle("Alert");
				tmpstage.initOwner(stage);
				
				Label label = new Label(e1.getMessage());
				label.setFont(Font.font(15));
				label.setAlignment(Pos.CENTER);
				Scene tmpScene = new Scene(label,400,100);
								
				tmpstage.setScene(tmpScene);
				tmpstage.show();				e1.printStackTrace();
			} catch (InvalidTargetException e1) {
				Stage tmpstage = new Stage();
				tmpstage.setTitle("Alert");
				tmpstage.initOwner(stage);
				
				Label label = new Label(e1.getMessage());
				label.setFont(Font.font(15));
				label.setAlignment(Pos.CENTER);
				Scene tmpScene = new Scene(label,400,100);
								
				tmpstage.setScene(tmpScene);
				tmpstage.show();				e1.printStackTrace();
			}
			
			
			
			
		});
		
		Button Cure = new Button("Cure");
		Cure.setPrefSize(120, 30);
		Cure.setOnAction(e -> {
			
			try {
				//data.setText(" ");
				hero.cure();
				m.fillthemap(Game.map);
				
				Point p2 = new Point(hero.getTarget().getLocation());
				int k = Math.abs(p2.x-14);
				int o = p2.y;
				int n = Game.heroes.size()-1;
				Text data2 = new Text("Name: " + Game.heroes.get(n).getName() + "\n" + "Type: Medic"  + "\n" + "HP: " + Game.heroes.get(n).getMaxHp()
						+ "\n" +"Attack dmg: " + Game.heroes.get(n).getAttackDmg()+ "\n" +"Actions Available: " + Game.heroes.get(n).getMaxActions());
				data2.setTextAlignment(TextAlignment.CENTER);
				data2.setFont(Font.font(15));
				data2.setFill(Color.WHITE);
				data2.setStroke(Color.RED);
				data2.setStrokeWidth(0.1);
				
				txt.setText("Name: " + hero.getName() + "\n" + "Current ActionPoints: " + hero.getActionsAvailable() +"\n" + "Current Hp: " + hero.getCurrentHp()
				+"\n"+ "supplies: " + hero.getSupplyInventory().size() + "\n" + "Vaccines: " + hero.getVaccineInventory().size());
				txt.setFill(Color.WHITE);
				
				Vtext.getChildren().add(data2);
				m.squares[k][o].setFill(new ImagePattern(figh));
				
				if(Game.checkGameOver()) 
					Gameovermsg();
				
				if(Game.checkWin())
					Winmsg();
				
			} catch (NoAvailableResourcesException e1) {
				Stage tmpstage = new Stage();
				tmpstage.setTitle("Alert");
				tmpstage.initOwner(stage);
				
				Label label = new Label(e1.getMessage());
				label.setFont(Font.font(15));
				label.setAlignment(Pos.CENTER);
				Scene tmpScene = new Scene(label,400,100);
								
				tmpstage.setScene(tmpScene);
				tmpstage.show();				
				
			} catch (InvalidTargetException e1) {
				Stage tmpstage = new Stage();
				tmpstage.setTitle("Alert");
				tmpstage.initOwner(stage);
				
				Label label = new Label(e1.getMessage());
				label.setFont(Font.font(15));
				label.setAlignment(Pos.CENTER);
				Scene tmpScene = new Scene(label,400,100);
								
				tmpstage.setScene(tmpScene);
				tmpstage.show();				
			} catch (NotEnoughActionsException e1) {
				Stage tmpstage = new Stage();
				tmpstage.setTitle("Alert");
				tmpstage.initOwner(stage);
				
				Label label = new Label(e1.getMessage());
				label.setFont(Font.font(15));
				label.setAlignment(Pos.CENTER);
				Scene tmpScene = new Scene(label,400,100);
								
				tmpstage.setScene(tmpScene);
				tmpstage.show();				e1.printStackTrace();
			}
			
			
		});
		
		
		Button UseSpecial = new Button("use special");
		UseSpecial.setPrefSize(120, 30);
		UseSpecial.setOnAction(e ->{
				
			
				try {
					if(hero instanceof Explorer) {
					hero.useSpecial();
					m.fillthemap2(Game.map);
					}
					else if(hero instanceof Fighter) {
						hero.useSpecial();
						hero.attack();
					}
					else if(hero instanceof Medic) {
						
						hero.useSpecial();
					}
					if(Game.checkGameOver()) 
						Gameovermsg();
					
					if(Game.checkWin())
						Winmsg();
					
					txt.setText("Name: " + hero.getName() + "\n" + "Current ActionPoints: " + hero.getActionsAvailable() +"\n" + "Current Hp: " + hero.getCurrentHp()
					+"\n"+ "supplies: " + hero.getSupplyInventory().size() + "\n" + "Vaccines: " + hero.getVaccineInventory().size());
					txt.setFill(Color.WHITE);
					
				} catch (NoAvailableResourcesException e1) {
					Stage tmpstage = new Stage();
					tmpstage.setTitle("Alert");
					tmpstage.initOwner(stage);
					
					Label label = new Label(e1.getMessage());
					label.setFont(Font.font(15));
					label.setAlignment(Pos.CENTER);
					Scene tmpScene = new Scene(label,400,100);
									
					tmpstage.setScene(tmpScene);
					tmpstage.show();					e1.printStackTrace();
				} catch (InvalidTargetException e1) {
					Stage tmpstage = new Stage();
					tmpstage.setTitle("Alert");
					tmpstage.initOwner(stage);
					
					Label label = new Label(e1.getMessage());
					label.setFont(Font.font(15));
					label.setAlignment(Pos.CENTER);
					Scene tmpScene = new Scene(label,400,100);
									
					tmpstage.setScene(tmpScene);
					tmpstage.show();					e1.printStackTrace();
				} catch (NotEnoughActionsException e1) {
					Stage tmpstage = new Stage();
					tmpstage.setTitle("Alert");
					tmpstage.initOwner(stage);
					
					Label label = new Label(e1.getMessage());
					label.setFont(Font.font(15));
					label.setAlignment(Pos.CENTER);
					Scene tmpScene = new Scene(label,400,100);
									
					tmpstage.setScene(tmpScene);
					tmpstage.show();
					e1.printStackTrace();
				}
				
			
			
			
			
		});
		
		Button Endturn = new Button("End Turn");
		Endturn.setPrefSize(120, 30);
		Endturn.setOnAction(e-> {
			
			try {
				Game.endTurn();
				
				m.fillthemap(Game.map);
				//m.GridVisibility(Game.map);
				
				for(int j = 0;j<Game.heroes.size();j++) {
					txt.setText("Name: " + hero.getName() + "\n" + "Current ActionPoints: " + hero.getActionsAvailable() +"\n" + "Current Hp: " + hero.getCurrentHp()
					+"\n"+ "supplies: " + hero.getSupplyInventory().size() + "\n" + "Vaccines: " + hero.getVaccineInventory().size());
					txt.setFill(Color.WHITE);
				}
				
				if(Game.checkGameOver()) 
					Gameovermsg();
				
				if(Game.checkWin())
					Winmsg();
				
			} catch (NotEnoughActionsException e1) {
				Stage tmpstage = new Stage();
				tmpstage.setTitle("Alert");
				tmpstage.initOwner(stage);
				
				Label label = new Label(e1.getMessage());
				label.setFont(Font.font(15));
				label.setAlignment(Pos.CENTER);
				Scene tmpScene = new Scene(label,400,100);
								
				tmpstage.setScene(tmpScene);
				tmpstage.show();
				e1.printStackTrace();
			} catch (InvalidTargetException e1) {
				Stage tmpstage = new Stage();
				tmpstage.setTitle("Alert");
				tmpstage.initOwner(stage);
				
				Label label = new Label(e1.getMessage());
				label.setFont(Font.font(15));
				label.setAlignment(Pos.CENTER);
				Scene tmpScene = new Scene(label,400,100);
								
				tmpstage.setScene(tmpScene);
				tmpstage.show();
				e1.printStackTrace();
			}
			
			
		});
		
		
//		Image image1 = new Image("up.png");
//      ImageView imageView1= new ImageView(image1);
        
		//bpane.getChildren().add(txt);
		Button up = new Button("UP");
		up.setPrefSize(120, 30);
		up.setOnAction(e ->{ 

				try {
					
					Point p1 = new Point(hero.getLocation());
					int k =Math.abs(p1.x-14);
					int o=p1.y;
					
					int Health = hero.getCurrentHp();
					
					hero.move(Direction.UP);
					m.fillthemap(Game.map);
					
					m.squares[k][o].setFill(Color.WHITE);
					m.squares[k-1][o].setFill(new ImagePattern(figh));
					
					if(hero.getCurrentHp()<Health) {
						trapmsg();
					}
	
					txt.setText("Name: " + hero.getName() + "\n" + "Current ActionPoints: " + hero.getActionsAvailable() +"\n" + "Current Hp: " + hero.getCurrentHp()
					+"\n"+ "supplies: " + hero.getSupplyInventory().size() + "\n" + "Vaccines: " + hero.getVaccineInventory().size());
					txt.setFill(Color.WHITE);
					
					if(Game.checkGameOver()) 
						Gameovermsg();
					
					if(Game.checkWin())
						Winmsg();

				} catch (MovementException e1) {
					Stage tmpstage = new Stage();
					tmpstage.setTitle("Alert");
					tmpstage.initOwner(stage);
					
					Label label = new Label(e1.getMessage());
					label.setFont(Font.font(15));
					label.setAlignment(Pos.CENTER);
					Scene tmpScene = new Scene(label,400,100);
									
					tmpstage.setScene(tmpScene);
					tmpstage.show();
				} catch (NotEnoughActionsException e1) {
					Stage tmpstage = new Stage();
					tmpstage.setTitle("Alert");
					tmpstage.initOwner(stage);
					
					Label label = new Label(e1.getMessage());
					label.setFont(Font.font(15));
					label.setAlignment(Pos.CENTER);
					Scene tmpScene = new Scene(label,400,100);
									
					tmpstage.setScene(tmpScene);
					tmpstage.show();
				}

			});
		

		Button down = new Button("DOWN");
		down.setPrefSize(120, 30);
		down.setOnAction(e ->{ 	

			try {
			
				Point p1 = new Point(hero.getLocation());
				int k = Math.abs(p1.x-14);
				int o = p1.y;
				
				int Health = hero.getCurrentHp();
				
				hero.move(Direction.DOWN);
				m.fillthemap(Game.map);
				
				m.squares[k][o].setFill(Color.WHITE);
				m.squares[k+1][o].setFill(new ImagePattern(figh));
				
				if(hero.getCurrentHp()<Health) {
					trapmsg();
				}
				
				txt.setText("Name: " + hero.getName() + "\n" + "Current ActionPoints: " + hero.getActionsAvailable() +"\n" + "Current Hp: " + hero.getCurrentHp()
				+"\n"+ "supplies: " + hero.getSupplyInventory().size() + "\n" + "Vaccines: " + hero.getVaccineInventory().size());
				txt.setFill(Color.WHITE);
				
				if(Game.checkGameOver()) 
					Gameovermsg();
				
				if(Game.checkWin())
					Winmsg();

			} catch (MovementException e1) {
				Stage tmpstage = new Stage();
				tmpstage.setTitle("Alert");
				tmpstage.initOwner(stage);
				
				Label label = new Label(e1.getMessage());
				label.setFont(Font.font(15));
				label.setAlignment(Pos.CENTER);
				Scene tmpScene = new Scene(label,400,100);
								
				tmpstage.setScene(tmpScene);
				tmpstage.show();
			} catch (NotEnoughActionsException e1) {
				Stage tmpstage = new Stage();
				tmpstage.setTitle("Alert");
				tmpstage.initOwner(stage);
				
				Label label = new Label(e1.getMessage());
				label.setFont(Font.font(15));
				label.setAlignment(Pos.CENTER);
				Scene tmpScene = new Scene(label,400,100);
								
				tmpstage.setScene(tmpScene);
				tmpstage.show();
			}

		});


		
		Button left = new Button("LEFT");
		left.setPrefSize(120, 30);
		left.setOnAction(e ->{ 		

			try {
				
				Point p1 = new Point(hero.getLocation());
				int k = Math.abs(p1.x-14);
				int o = p1.y;
				
				int Health = hero.getCurrentHp();
				
				hero.move(Direction.LEFT);
				m.fillthemap(Game.map);
				
				m.squares[k][o].setFill(Color.WHITE);
				m.squares[k][o-1].setFill(new ImagePattern(figh));
				
				if(hero.getCurrentHp()<Health) {
					trapmsg();
				}
				
				txt.setText("Name: " + hero.getName() + "\n" + "Current ActionPoints: " + hero.getActionsAvailable() +"\n" + "Current Hp: " + hero.getCurrentHp()
				+"\n"+ "supplies: " + hero.getSupplyInventory().size() + "\n" + "Vaccines: " + hero.getVaccineInventory().size());
				txt.setFill(Color.WHITE);
				
				if(Game.checkGameOver()) 
					Gameovermsg();
				
				if(Game.checkWin())
					Winmsg();

			} catch (MovementException e1) {
				Stage tmpstage = new Stage();
				tmpstage.setTitle("Alert");
				tmpstage.initOwner(stage);
				
				Label label = new Label(e1.getMessage());
				label.setFont(Font.font(15));
				label.setAlignment(Pos.CENTER);
				Scene tmpScene = new Scene(label,400,100);
								
				tmpstage.setScene(tmpScene);
				tmpstage.show();
				
			} catch (NotEnoughActionsException e1) {
				Stage tmpstage = new Stage();
				tmpstage.setTitle("Alert");
				tmpstage.initOwner(stage);
				
				Label label = new Label(e1.getMessage());
				label.setFont(Font.font(15));
				label.setAlignment(Pos.CENTER);
				Scene tmpScene = new Scene(label,400,100);
								
				tmpstage.setScene(tmpScene);
				tmpstage.show();

			}

		});

	
		Button right = new Button("RIGHT");
		right.setPrefSize(120, 30);
		right.setOnAction(e ->{ 

			try {
				
				Point p1 = new Point(hero.getLocation());
				int k = Math.abs(p1.x-14);
				int o = p1.y;
				
				int Health = hero.getCurrentHp();
				
				hero.move(Direction.RIGHT);
				m.fillthemap(Game.map);
				
				m.squares[k][o].setFill(Color.WHITE);
				m.squares[k][o+1].setFill(new ImagePattern(figh));
				
				if(hero.getCurrentHp()<Health) {
					trapmsg();
				}
				
				txt.setText("Name: " + hero.getName() + "\n" + "Current ActionPoints: " + hero.getActionsAvailable() +"\n" + "Current Hp: " + hero.getCurrentHp()
				+"\n"+ "supplies: " + hero.getSupplyInventory().size() + "\n" + "Vaccines: " + hero.getVaccineInventory().size());
				txt.setFill(Color.WHITE);
				
				if(Game.checkGameOver()) 
					Gameovermsg();
				
				if(Game.checkWin())
					Winmsg();

			} catch (MovementException e1) {
				Stage tmpstage = new Stage();
				tmpstage.setTitle("Alert");
				tmpstage.initOwner(stage);
				
				Label label = new Label(e1.getMessage());
				label.setFont(Font.font(15));
				label.setAlignment(Pos.CENTER);
				Scene tmpScene = new Scene(label,400,100);
								
				tmpstage.setScene(tmpScene);
				tmpstage.show();// TODO Auto-generated catch block
				//e1.printStackTrace();
			} catch (NotEnoughActionsException e1) {
				Stage tmpstage = new Stage();
				tmpstage.setTitle("Alert");
				tmpstage.initOwner(stage);
				
				Label label = new Label(e1.getMessage());
				label.setFont(Font.font(15));
				label.setAlignment(Pos.CENTER);
				Scene tmpScene = new Scene(label,400,100);
								
				tmpstage.setScene(tmpScene);
				tmpstage.show();// TODO Auto-generated catch block
				//e1.printStackTrace();
			}

		});


		
		
		
		bpane.getChildren().addAll(Atk,Cure,UseSpecial,Endturn,up,down,left,right,txt);
		mapGrid.add(bpane, 20, 0, 1, 20);
		mapGrid.add(Vtext,30,0,1,30);
		tmp.getChildren().add(mapGrid);
		
		
		scene3 = new Scene(tmp,1100,650,Color.BLACK);
		scene2 = new Scene(root2,1100,650,Color.BLACK);
		
		
		
		Image logo = new Image("wp10887314.jpg");	
		stage.getIcons().add(logo);
		stage.setTitle("The Last of us");
		stage.setScene(scene1);
		stage.show();
	}
	
	public void Gameovermsg() {
		Stage tmpstage = new Stage();
		tmpstage.setTitle("The Last of us");
		tmpstage.initOwner(stage);
		
		Label label = new Label("GAME OVER");
		label.setFont(Font.font(15));
		label.setAlignment(Pos.CENTER);
		Scene tmpScene = new Scene(label,400,100);
						
		tmpstage.setScene(tmpScene);
		tmpstage.show();
		tmpstage.setOnCloseRequest(event -> {
		    Platform.exit();
		    System.exit(0);
		});
	}
	
	public void Winmsg() {
		Stage tmpstage = new Stage();
		tmpstage.setTitle("The Last of us");
		tmpstage.initOwner(stage);
		
		Label label = new Label("You win");
		label.setFont(Font.font(15));
		label.setAlignment(Pos.CENTER);
		Scene tmpScene = new Scene(label,400,100);
						
		tmpstage.setScene(tmpScene);
		tmpstage.show();
		tmpstage.setScene(tmpScene);
		tmpstage.show();
		tmpstage.setOnCloseRequest(event -> {
		    Platform.exit();
		    System.exit(0);
		});
	}
	
	public void trapmsg() {
		Stage tmpstage = new Stage();
		tmpstage.setTitle("The Last of us");
		tmpstage.initOwner(stage);
		
		Label label = new Label("You stepped into a TrapCell");
		label.setFont(Font.font(15));
		label.setAlignment(Pos.CENTER);
		Scene tmpScene = new Scene(label,400,100);
						
		tmpstage.setScene(tmpScene);
		tmpstage.show();
	}


	
	
	


	public static void main(String[] args) {
		launch(args);
	}
	
	
	
	
	
	
	
}
